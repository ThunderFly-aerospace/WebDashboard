# mavlink-websocket

MAVLink–WebSocket proxy written in Python using [Tornado](http://www.tornadoweb.org).

Allows creating web GUIs for vehicles, communicating with [MAVLink](https://mavlink.io/en/) protocol. See [Common Message Set](https://mavlink.io/en/messages/common.html) to get messages definitions information.
